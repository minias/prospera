// src/lib/infrastructure/three/ThreeWorld.ts

import * as THREE from 'three';
import { WorldState } from '../../domain/world/WorldState';

export interface ThreeWorldOptions {
  antialias?: boolean;
  alpha?: boolean;
}

export class ThreeWorld {
  readonly state = new WorldState();

  private readonly scene: THREE.Scene;
  private readonly camera: THREE.PerspectiveCamera;
  private readonly renderer: THREE.WebGLRenderer;
  private readonly cube: THREE.Mesh<THREE.BoxGeometry, THREE.MeshStandardMaterial>;
  private readonly resizeObserver: ResizeObserver;
  private readonly container: HTMLElement;

  private disposed = false;

  constructor(container: HTMLElement, options: ThreeWorldOptions = {}) {
    this.container = container;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x05070a);

    const width = Math.max(container.clientWidth, 1);
    const height = Math.max(container.clientHeight, 1);

    this.camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 100);
    this.camera.position.set(0, 1.5, 5);
    this.camera.lookAt(0, 0, 0);

    this.renderer = new THREE.WebGLRenderer({
      antialias: options.antialias ?? true,
      alpha: options.alpha ?? false
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(width, height, false);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;

    const ambientLight = new THREE.AmbientLight(0xffffff, 1.5);
    this.scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 2);
    keyLight.position.set(3, 5, 4);
    this.scene.add(keyLight);

    const geometry = new THREE.BoxGeometry(1, 1, 1);
    const material = new THREE.MeshStandardMaterial({
      color: 0x66ccff,
      roughness: 0.35,
      metalness: 0.15
    });
    this.cube = new THREE.Mesh(geometry, material);
    this.scene.add(this.cube);

    container.replaceChildren(this.renderer.domElement);

    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(container);

    this.resize();
    this.state.start();
    this.renderer.setAnimationLoop(() => this.render());
  }

  private resize(): void {
    if (this.disposed) return;

    const width = Math.max(this.container.clientWidth, 1);
    const height = Math.max(this.container.clientHeight, 1);

    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height, false);
  }

  private render(): void {
    if (this.disposed) return;

    this.cube.rotation.x += 0.005;
    this.cube.rotation.y += 0.008;

    this.state.tick();
    this.renderer.render(this.scene, this.camera);
  }

  dispose(): void {
    if (this.disposed) return;

    this.disposed = true;
    this.state.dispose();
    this.renderer.setAnimationLoop(null);
    this.resizeObserver.disconnect();

    this.cube.geometry.dispose();
    this.cube.material.dispose();
    this.scene.clear();
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }
}
