<!-- src/routes/+page.svelte -->
<script lang="ts">
  import WorldCanvas from '$lib/components/world/WorldCanvas.svelte';
</script>

<svelte:head>
  <title>Prospera World</title>
  <meta
    name="description"
    content="Prospera World — Enter the Intelligence."
  />
</svelte:head>

<main class="world-page">
  <WorldCanvas />
</main>

<style>
  .world-page {
    position: fixed;
    inset: 0;
    overflow: hidden;
    background: #05070a;
  }
</style>
